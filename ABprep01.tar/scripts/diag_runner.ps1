cd D:\Projects\AudioBooks\ABprep01
.\.venv\Scripts\Activate.ps1

python .\scripts\diag_xtts.py
python .\scripts\diag_donu.py
python .\scripts\test_tts.py
